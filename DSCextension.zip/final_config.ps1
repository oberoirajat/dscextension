configuration Serviceconfig
{

Import-DSCResource -ModuleName xDSCFirewall
Import-DSCResource -ModuleName psdesiredstateconfiguration
Import-DscResource -ModuleName xPSDesiredStateConfiguration
Import-DSCResource -ModuleName xTimeZone
Import-DscResource -module xWinEventLog


node localhost
{
  WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }

Service WindowsFirewall
{
Name = "MPSSvc"
StartupType = "Automatic"
State = "Running"
}
xDSCFirewall DisablePublic
{
  Ensure = "Absent"
  Zone = "Public"
  Dependson = "[Service]WindowsFirewall"
}
xDSCFirewall EnabledPrivate
{
  Ensure = "Present"
  Zone = "Private"
  Dependson = "[Service]WindowsFirewall"
}  
 

    xService Special_Administration_Console_Helper
    {
        Name = 'Sacsvr'
        StartupType = 'Manual'    
        State = 'Stopped'
    }

    xService Smart_card
    {
        Name = 'SCardSvr'
        StartupType = 'Manual'    
        State = 'Stopped'
    }

    xService Portable_Device_Enumerator_Service
    {
        Name = 'WPDBusEnum'
        StartupType = 'Manual'    
        State = 'Stopped'
    }

    xService Internet_Connection_Sharing
    {
        Name = 'SharedAccess'
        StartupType = 'Manual'    
        State = 'Stopped'
    }

    xService Human_Interface_Device_Service
    {
        Name = 'hidserv'
        StartupType = 'Manual'    
        State = 'Running'
    }

     xTimeZone TimeZoneExample
        {
            IsSingleInstance = 'Yes'
            TimeZone         = "Fiji Standard Time"
        }

        xWinEventLog Demo1
    {
        LogName            = "Application"
        IsEnabled          = $true
        LogMode            = "AutoBackup"
        MaximumSizeInBytes = 20mb
        
    }
    WindowsFeature Telnet
    {
        Ensure = "Present"
        Name ="Telnet-Client"
    
    }

Registry WUServer
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate"
        ValueName = 'WUServer'
        ValueType = 'String'
        ValueData = 'http://testvm.pullserver.com:8530'
        Ensure = "Present"
    }

Registry StatusServer
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate"
        ValueName = 'WUStatusServer'
        ValueType = 'String'
        ValueData = 'http://testvm.pullserver.com:8530'
        Ensure = "Present"

    }

Registry SetTargetGroup
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate"
        ValueName = 'TargetGroup'
        ValueType = 'String'
        ValueData = 'TestServers'
        Ensure = "Present"

    }

Registry TargetMode
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate"
        ValueName = 'TargetGroupEnabled'
        ValueType = 'Dword'
        ValueData = 1
        Ensure = "Present"
    }


Registry InstallOption
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate\AU"
        ValueName = 'AUOptions'
        ValueType = 'Dword'
        ValueData = 4
        Ensure = "Present"
    }

Registry WSUSServer
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate\AU"
        ValueName = 'UseWUServer'
        ValueType = 'Dword'
        ValueData = 1
        Ensure = "Present"
    }

Registry DetectFrequency
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate\AU"
        ValueName = 'DetectionFequency'
        ValueType = 'Dword'
        ValueData = 1
        Ensure = "Present"
    }

Registry InstallTime
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate\Au"
        ValueName = 'ScheduledInstallTime'
        ValueType = 'Dword'
        ValueData = '13'
        Ensure = "Present"
    }

Registry AutoRebootTime
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate\AU"
        ValueName = 'AlwaysAutoRebootAtSchduledTime'
        ValueType = 'Dword'
        ValueData = 1
        Ensure = "Present"
    }

Registry RebootMinutes
    {
        key="HKLM:\Software\Policies\MIcrosoft\Windows\WindowsUpdate\AU"
        ValueName =  'AlwaysAutoRebootAtSchduledTimeMinutes'
        ValueType = 'Dword'
        ValueData = '15'
        Ensure = "Present"
    }


}
}

Serviceconfig -OutputPath c:\serviceconfig
Start-DscConfiguration -ComputerName localhost -path C:\serviceconfig -Force -Wait -Verbose

